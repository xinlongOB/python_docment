def receive():
    return  "这是10010的短信"