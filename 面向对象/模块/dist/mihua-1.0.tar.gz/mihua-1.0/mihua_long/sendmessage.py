def send(text):
    print("正在发生 %s" % text)